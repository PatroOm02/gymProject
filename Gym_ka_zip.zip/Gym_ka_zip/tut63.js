// console.log("Hello World");
const http = require('http');

const hostname = '127.0.0.1';
const port = 3000;

const server = http.createServer((req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/html');
  res.end(`<!DOCTYPE html>
  <html lang="en">
  <head>
      <title>Images</title>
  </head>
  
  <body>
      <h2>Avengers</h2>
      <img src = "https://cdn.britannica.com/49/182849-050-4C7FE34F/scene-Iron-Man.jpg" alt = "Iron Man" title = "Tony Stark" width = "600" height = "400">
      <br><br>
  
      <img src = "https://static.toiimg.com/thumb/msid-92807013,imgsize-69816,width-800,height-600,resizemode-75/92807013.jpg" alt = "Captain America" title = "Steve Rogers" width = "600" height = "450">
      <br><br>
  
      <img src = "https://comics2film.com/images/1056/594/1/thor-the-dark-world-chris-hemsworth-marvel-studios-wallpaper.jpg" alt = "Thor" title = "Thor Odinson" width = "600" height = "400">
      <br><br>
  
      <img src = "https://www.pinkvilla.com/imageresize/AvengersHulk.jpg?width=752&t=pvorg" alt = "Hulk" title = "Bruce Banner" title = "600" height = "400">
      <br><br>
  
      <img src = "https://i.pinimg.com/originals/bc/af/ea/bcafea3c7185f173c9d0acf22bdb0c8d.jpg" alt = "Hawkeye" title = "Clint Barton" width = "600" height = "500">
      <br><br>
  
      <img src = "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/black-widow-scarlett-johansson-marvel-1559233664.jpg?crop=0.668xw:1.00xh;0.235xw,0&resize=980:*" alt = "Black Widow" title = "Natasha Romanoff" width = "600" height = "500">
      <br><br>
  
      <hr>
  
      <img src = "https://www.siasat.com/wp-content/uploads/2021/01/Mukesh-Ambani-Gautam-Adani.jpg" alt = "Richie Rich" title = "Rich Gujaratis" border = "2" width = "200" height = "200">
      <br>
  
      <img src = "https://www.siasat.com/wp-content/uploads/2021/01/Mukesh-Ambani-Gautam-Adani.jpg" alt = "Richie Rich" title = "Rich Gujaratis" width = "720" height = "480" align = "right">
      <br>
  
      <a href = "w11.html" target = "_blank">First Exercise</a>
      <a href = "w12.html" target = "_blank">Second Exercise</a>
      <a href = "w13.html" target = "_blank">Third Exercise</a>
      <a href = "w14.html" target = "_blank">Fourth Exercise</a>
  
  </body>
  </html>`);
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});